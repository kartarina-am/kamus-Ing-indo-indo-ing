package kamusterjemahan.submission.app.kamusterjemahan.models;

import android.os.Parcel;
import android.os.Parcelable;

public class TranslationModel implements Parcelable {
    private int id;
    private String word;
    private String translation;

    public TranslationModel(String word, String translation) {
        this.word = word;
        this.translation = translation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getTranslation() {
        return translation;
    }

    public void setTranslation(String translation) {
        this.translation = translation;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.word);
        dest.writeString(this.translation);
    }

    public TranslationModel(int id, String word, String translation) {
        this.id = id;
        this.word = word;
        this.translation = translation;
    }

    public TranslationModel() {
    }

    private TranslationModel(Parcel in) {
        this.word = in.readString();
        this.translation = in.readString();
    }

    public static final Creator<TranslationModel> CREATOR = new Creator<TranslationModel>() {
        @Override
        public TranslationModel createFromParcel(Parcel source) {
            return new TranslationModel(source);
        }

        @Override
        public TranslationModel[] newArray(int size) {
            return new TranslationModel[size];
        }
    };

    @Override
    public String toString() {
        return word;
    }
}
