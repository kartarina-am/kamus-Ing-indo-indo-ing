package kamusterjemahan.submission.app.kamusterjemahan.activities;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ProgressBar;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import kamusterjemahan.submission.app.kamusterjemahan.R;
import kamusterjemahan.submission.app.kamusterjemahan.database.WordHelpers;
import kamusterjemahan.submission.app.kamusterjemahan.models.TranslationModel;
import kamusterjemahan.submission.app.kamusterjemahan.utils.MyPreference;

public class Preload extends AppCompatActivity {

    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        progressBar = findViewById(R.id.progressbar);
        new LoadData().execute();
    }

    private class LoadData extends AsyncTask<Void, Integer, Void> {

        final String TAG = LoadData.class.getSimpleName();
        WordHelpers wordHelpers;
        MyPreference appPreference;

        @Override
        protected void onPreExecute() {
            wordHelpers = new WordHelpers(Preload.this);
            appPreference = new MyPreference(Preload.this);
        }

        @Override
        protected Void doInBackground(Void... params) {
            Boolean isFirst = appPreference.getIsFirst();
            if (isFirst) {
                ArrayList<TranslationModel> idToEnLists = getIdToEnAsset();
                ArrayList<TranslationModel> enToIdLists = getEnToIdAsset();

                wordHelpers.open();

                int maxProgress = idToEnLists.size() + enToIdLists.size();
                int progress = 0;
                progressBar.setMax(maxProgress);

                wordHelpers.beginTransaction();

                try {
                    for (TranslationModel model : idToEnLists) {
                        wordHelpers.insertIntoTableIdEn(model);
                        progress++;
                        publishProgress(progress);
                    }

                    for (TranslationModel model : enToIdLists) {
                        wordHelpers.insertIntoTableEnId(model);
                        progress++;
                        publishProgress(progress);
                    }

                    wordHelpers.setTransactionSuccess();
                } catch (Exception e) {
                    Log.e(TAG, "doInBackground: " + e.getMessage());
                }
                wordHelpers.endTransaction();
                wordHelpers.close();
                appPreference.setIsFirst(false);
            } else {
                try {
                    synchronized (this) {
                        int progress = 0;
                        for (int i = 1; i <= 100; i++) {
                            this.wait(20);
                            progress += i;
                            publishProgress((int) progress);
                        }
                    }
                } catch (Exception ignored) {
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            int progress = values[0];
            progressBar.setProgress(progress);
        }

        @Override
        protected void onPostExecute(Void result) {
            Intent i = new Intent(Preload.this, Translate.class);
            startActivity(i);
            finish();
        }
    }

    public ArrayList<TranslationModel> getIdToEnAsset() {
        return loadDictAsset("indonesia_english");
    }

    public ArrayList<TranslationModel> getEnToIdAsset() {
        return loadDictAsset("english_indonesia");
    }

    public ArrayList<TranslationModel> loadDictAsset(String assetName) {
        ArrayList<TranslationModel> wordList = new ArrayList<>();
        String line = null;
        BufferedReader reader;
        try {
            reader = new BufferedReader(new InputStreamReader(getAssets().open(assetName)));
            do {
                line = reader.readLine();
                if (line == null) continue;

                String[] tabSparated = line.split("\t");
                TranslationModel wordModel;
                wordModel = new TranslationModel(tabSparated[0], tabSparated[1]);
                wordList.add(wordModel);
            } while (line != null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return wordList;
    }

}
