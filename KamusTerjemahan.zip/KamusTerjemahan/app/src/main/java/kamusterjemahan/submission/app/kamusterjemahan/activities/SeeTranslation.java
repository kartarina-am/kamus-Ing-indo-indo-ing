package kamusterjemahan.submission.app.kamusterjemahan.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.Objects;

import kamusterjemahan.submission.app.kamusterjemahan.R;
import kamusterjemahan.submission.app.kamusterjemahan.models.TranslationModel;

public class SeeTranslation extends AppCompatActivity {

    public final static String WORD_LIST = "word_list";
    protected TranslationModel wordModel;
    private TextView tvWord, tvMean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_word);

        tvMean = findViewById(R.id.tv_dtl_mean);
        tvWord = findViewById(R.id.tv_dtl_word);

        wordModel = getIntent().getParcelableExtra(WORD_LIST);

        tvWord.setText(wordModel.getWord());
        tvMean.setText(wordModel.getTranslation());

        Objects.requireNonNull(getSupportActionBar()).setTitle(wordModel.getWord());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
