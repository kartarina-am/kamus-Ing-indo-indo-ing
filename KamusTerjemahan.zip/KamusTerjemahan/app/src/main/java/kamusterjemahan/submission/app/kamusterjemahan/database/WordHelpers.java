package kamusterjemahan.submission.app.kamusterjemahan.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.ArrayList;

import kamusterjemahan.submission.app.kamusterjemahan.models.TranslationModel;

import static android.provider.BaseColumns._ID;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.TABLE_EN_ID;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.TABLE_ID_EN;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.WordColumn.TRANSLATION;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.WordColumn.WORD;

public class WordHelpers {
    private Context context;
    private AppDBOpenHelper appDBOpenHelper;
    private SQLiteDatabase database;

    public WordHelpers(Context context) {
        this.context = context;
    }

    public WordHelpers open() throws SQLException {
        appDBOpenHelper = new AppDBOpenHelper(context);
        database = appDBOpenHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        appDBOpenHelper.close();
    }


    private Cursor getAllCursor(String tableName) {
        Cursor cursor = database
                .query(tableName,
                        null,
                        null,
                        null,
                        null,
                        null,
                        _ID + " ASC",
                        null);
        cursor.moveToFirst();
        return cursor;
    }

    private Cursor searchCursor(String tableName, String query) {
        Cursor cursor = database
                .query(tableName, null,
                        WORD + " LIKE ?",
                        new String[]{query},
                        null,
                        null,
                        _ID + " ASC",
                        null);

        cursor.moveToFirst();
        return cursor;
    }

    private ArrayList<TranslationModel> getAllToListModel(String tableName) {
        Cursor cursor = getAllCursor(tableName);
        ArrayList<TranslationModel> models = new ArrayList<>();
        if (cursor.getCount() > 0) {
            do {
                models.add(
                        new TranslationModel(
                                cursor.getInt(cursor.getColumnIndexOrThrow(_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(WORD)),
                                cursor.getString(cursor.getColumnIndexOrThrow(TRANSLATION))));
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        } else
            Log.i(String.format("ALL %s", tableName), "Data ID: " + models);
        cursor.close();
        return models;
    }

    private ArrayList<TranslationModel> searchToListModel(String tableName, String word) {
        ArrayList<TranslationModel> models = new ArrayList<>();
        Cursor cursor = searchCursor(tableName, word);
        if (cursor.getCount() > 0) {
            do {
                models.add(
                        new TranslationModel(
                                cursor.getInt(cursor.getColumnIndexOrThrow(_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(WORD)),
                                cursor.getString(cursor.getColumnIndexOrThrow(TRANSLATION))));
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return models;
    }

    public ArrayList<TranslationModel> getAllIdToEn() {
        return getAllToListModel(TABLE_ID_EN);
    }

    public ArrayList<TranslationModel> getAllEnToId() {
        return getAllToListModel(TABLE_EN_ID);
    }


    public ArrayList<TranslationModel> searchIdToEn(String word) {
        return searchToListModel(TABLE_ID_EN, word);
    }

    public ArrayList<TranslationModel> searchEnToId(String word) {
        return searchToListModel(TABLE_EN_ID, word);
    }

    public long insert(TranslationModel wordModel) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(WORD, wordModel.getWord());
        initialValues.put(TRANSLATION, wordModel.getTranslation());
        return database.insert(TABLE_ID_EN, null, initialValues);
    }

    public void beginTransaction() {
        database.beginTransaction();
    }

    public void setTransactionSuccess() {
        database.setTransactionSuccessful();
    }

    public void endTransaction() {
        database.endTransaction();
    }

    private void insertInto(String tableName, TranslationModel data) {
        String sql = "INSERT INTO " + tableName + " (" + WORD + ", " + TRANSLATION
                + ") VALUES (?, ?)";
        SQLiteStatement stmt = database.compileStatement(sql);
        stmt.bindString(1, data.getWord());
        stmt.bindString(2, data.getTranslation());
        stmt.execute();
        stmt.clearBindings();
    }

    public void insertIntoTableIdEn(TranslationModel data) {
        insertInto(TABLE_ID_EN, data);
    }

    public void insertIntoTableEnId(TranslationModel data) {
        insertInto(TABLE_EN_ID, data);
    }
}
