package kamusterjemahan.submission.app.kamusterjemahan.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import kamusterjemahan.submission.app.kamusterjemahan.R;

public class MyPreference {
    private SharedPreferences prefs;
    private Context context;

    public MyPreference(Context context) {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
        this.context = context;
    }

    public void setIsFirst(Boolean input) {
        SharedPreferences.Editor editor = prefs.edit();
        String key = context.getResources().getString(R.string.is_first);
        editor.putBoolean(key, input);
        editor.apply();
    }

    public Boolean getIsFirst() {
        String key = context.getResources().getString(R.string.is_first);
        return prefs.getBoolean(key, true);
    }
}
