package kamusterjemahan.submission.app.kamusterjemahan.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static android.provider.BaseColumns._ID;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.TABLE_EN_ID;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.TABLE_ID_EN;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.WordColumn.TRANSLATION;
import static kamusterjemahan.submission.app.kamusterjemahan.database.DatabaseConstants.WordColumn.WORD;

public class AppDBOpenHelper extends SQLiteOpenHelper {

    private static String DATABASE = "translate_app.db";
    private static final int VERSION = 1;

    private static String ID_EN_TABLE_NAME = "create table " + TABLE_ID_EN +
            " (" + _ID + " integer primary key autoincrement, " +
            WORD + " text not null, " +
            TRANSLATION + " text not null);";

    private static String EN_ID_TABLE_NAME = "create table " + TABLE_EN_ID +
            " (" + _ID + " integer primary key autoincrement, " +
            WORD + " text not null, " +
            TRANSLATION + " text not null);";

    AppDBOpenHelper(Context context) {
        super(context, DATABASE, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(ID_EN_TABLE_NAME);
        db.execSQL(EN_ID_TABLE_NAME);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ID_EN);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EN_ID);
        onCreate(db);
    }
}
