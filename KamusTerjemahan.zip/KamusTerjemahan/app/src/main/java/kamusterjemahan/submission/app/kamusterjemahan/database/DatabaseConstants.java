package kamusterjemahan.submission.app.kamusterjemahan.database;

import android.provider.BaseColumns;

class DatabaseConstants {

    static String TABLE_ID_EN = "indonesia_english";
    static String TABLE_EN_ID = "english_indonesia";

    static final class WordColumn implements BaseColumns {
        static String WORD = "word";
        static String TRANSLATION = "translation";
    }

}
